const student ={
    ID:123456,
    age:28,
    name: "Binazir",
    isStudent : false
}
const newJson = JSON.stringify(student);
console.log(newJson);
const book = `{
    "name" : "Harry Potter",
    "genre" : "Fantasy"
}`
const bookObject = JSON.parse(book);
console.log(bookObject)


// API 
const dataToRead =[
    {
        "title": "The Hobbit",
        "author" : "J.R.R Tolkein",
        "publish" : 1945

    },
    {
        "title": "1984",
        "author" : "George Orwell",
        "publish" : 1949
    }
]
for (let i = 0; i < dataToRead.length; i++) {
    // setup table
    const table = document.getElementById("tableData");
    const tableRow = table.insertRow(-1);
    // set cells 
    const cell1 = tableRow.insertCell(0);
    const cell2 = tableRow.insertCell(1);
    const cell3 = tableRow.insertCell(2);
    // populate the cells
  cell1.innerHTML = dataToRead[i].title;

  cell2.innerHTML = dataToRead[i].author;
  cell3.innerHTML = dataToRead[i].publish;

    
}
// fetch fata from Book.json
console.log("We will see the fetch from book.json")
fetch('book.json')
.then(response => response.json())
.then(data => console.log(data))

// get data from book.json into our website: 
fetch('book.json')
.then(response => response.json())
.then (data => {
    const tableone = document.getElementById("jsonTable");
    for (let i = 0; i < data.length; i++) {
        // setup table
        const book = data[i];
        const tableRow = tableone.insertRow(-1);
        // set cells 
        const cell1 = tableRow.insertCell(0);
        const cell2 = tableRow.insertCell(1);
        const cell3 = tableRow.insertCell(2);
        // populate the cells
      cell1.innerHTML = data.title;
    
      cell2.innerHTML = book.author;
      cell3.innerHTML = book.publish;
    
        
    }
})
// fetch using : https://jsonplaceholder.typicode.com/users
console.log("data coming form my API ")

fetch('https://jsonplaceholder.typicode.com/users')
.then(response => response.json())
.then(users => {
    const table = document.getElementById("placeholderjson");
    for (let i = 0; i < users.length; i++) {
        const tableRow = table.insertRow(-1);
        const user = users[i];
  
        // set cells 
        const cell1 = tableRow.insertCell(0);
        const cell2 = tableRow.insertCell(1);
        const cell3 = tableRow.insertCell(2);
        // populate the cells
      cell1.innerHTML = user.name;
    
      cell2.innerHTML = user.username;
      cell3.innerHTML = user.email;
        
    }
} );
// async/await
async function getJason(){
    const response = await fetch('https://jsonplaceholder.typicode.com/users');
    const data = await response.json();
    console.log(data);
}
getJason();